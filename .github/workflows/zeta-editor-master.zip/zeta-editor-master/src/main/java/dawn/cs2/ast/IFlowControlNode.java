package dawn.cs2.ast;

public interface IFlowControlNode {

	public IControllableFlowNode getNode();
}
