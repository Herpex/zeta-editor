package dawn.cs2.ast;

public interface IIntConstantNode {

	
	/**
	 * Returns constant of this node.
	 */
	Integer getConst();
}
