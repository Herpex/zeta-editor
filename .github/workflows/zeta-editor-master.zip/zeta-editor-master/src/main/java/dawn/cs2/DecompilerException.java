package dawn.cs2;

public class DecompilerException extends RuntimeException {

	public DecompilerException(String string) {
		super(string);
	}

}
