package dawn.cs2.ast;

public interface IControllableFlowNode extends ILabelableNode {

}
