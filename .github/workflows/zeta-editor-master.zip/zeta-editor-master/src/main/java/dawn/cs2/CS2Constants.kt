package dawn.cs2

const val GENERATE_SCRIPTS_DB = false
const val DEBUG = false