package com.displee.editor.ui.autocomplete

enum class AutoCompleteItemType {
	ARGUMENT,
	FIELD,
	METHOD,
	VARIABLE,
	CONSTANT
}