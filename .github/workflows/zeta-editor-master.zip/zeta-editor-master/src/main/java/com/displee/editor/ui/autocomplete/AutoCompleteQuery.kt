package com.displee.editor.ui.autocomplete

class AutoCompleteQuery(val line: String, val word: String) {}