# Displee's CS2 editor
This is an attempt in creating a simple editor for Vincent's CS2 compiler/decompiler. There is also support for viewing the assembly of the script.

## Hotkeys
These keys are currently handled by the program:
- Ctrl + N Create new script
- Ctrl + S Compile script
- Ctrl + D Pack script

## Media
![Script example](https://i.imgur.com/SEH2GpT.png)
